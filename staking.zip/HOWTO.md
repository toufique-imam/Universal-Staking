IF you have linux run 'run.linux.sh'
if you have mac with intel chip run 'run.mac.intel.sh'
if you have mac with m1/m2 chip run 'run.mac.m1.sh', make sure you have rosetta installed